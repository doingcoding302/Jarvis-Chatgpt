# Jarvis Android — starter project

A free-first native Android starter for a futuristic personal AI assistant.

## Included in this starter
- Jetpack Compose dark/light interface with a glass-inspired look
- Editable assistant name and preferred form of address
- Floating, draggable overlay orb (requires the user to grant overlay permission)
- Tap the orb to open the assistant and start speech input
- Android speech recognition + text-to-speech response (basic local demo responses)
- Personal / Business mode switch
- Notification permission request on Android 13+
- A clear place to connect a real AI API and business integrations

## Important limits
This is a starter app, not a complete movie-style JARVIS. Android does not allow an ordinary app to control every app or silently perform every action. Overlay, microphone, notifications, accessibility, background activity, and app-launch features have separate OS restrictions. YouTube "viral video" alerts need YouTube/Google OAuth and authorized YouTube Data API access; this starter does not pretend to monitor a channel yet.

The included assistant replies are demo logic. To add a real model, create a backend that keeps the API key secret and connect it to `AssistantRepository`. Do not put paid API keys in the Android app or public GitHub repo.

## Build
1. Install Android Studio on a computer (recommended) and open this folder.
2. Let Gradle sync.
3. Run on an Android device/emulator.
4. On the phone, enable **Display over other apps** when prompted.
5. For speech, grant microphone permission when requested.

This project targets Android 8.0+ (API 26) as a practical baseline. The overlay and background behavior may differ across Android versions and manufacturers.

## Push to GitHub from an Android tablet
1. Extract this ZIP.
2. Open `https://github.com/new` and create a repository named `jarvis-android`.
3. On the new repository page, choose **uploading an existing file**.
4. Upload the extracted project files/folders. If the mobile page is awkward, use your browser's **Desktop site** option.
5. Commit the files. Never upload secrets, signing keys, or API keys.

A GitHub repository stores the code; it does not itself compile an APK. For builds from GitHub, add a GitHub Actions Android workflow after the starter is uploaded.
