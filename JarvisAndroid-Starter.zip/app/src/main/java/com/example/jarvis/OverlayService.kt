package com.example.jarvis

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import android.graphics.Color
import android.view.WindowManager.LayoutParams

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var orb: TextView? = null
    private var params: LayoutParams? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (orb == null) showOrb()
        return START_STICKY
    }

    private fun showOrb() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = TextView(this).apply {
            text = "✦"
            textSize = 28f
            setTextColor(Color.rgb(101, 231, 255))
            gravity = Gravity.CENTER
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(27, 49, 84), Color.rgb(8, 12, 26))
            ).apply {
                shape = GradientDrawable.OVAL
                setStroke(3, Color.rgb(101, 231, 255))
            }
            elevation = 18f
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") LayoutParams.TYPE_PHONE
        val lp = LayoutParams(68, 68, type, LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 28; y = 260
        }
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = event.rawX; touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val moved = kotlin.math.abs(event.rawX - touchX) > 12 || kotlin.math.abs(event.rawY - touchY) > 12
                    if (!moved) {
                        val i = Intent(this, MainActivity::class.java).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                            putExtra("start_listening", true)
                        }
                        startActivity(i)
                    }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (event.rawX - touchX).toInt()
                    lp.y = startY + (event.rawY - touchY).toInt()
                    wm.updateViewLayout(view, lp)
                    true
                }
                else -> false
            }
        }
        orb = view
        params = lp
        wm.addView(view, lp)
    }

    override fun onDestroy() {
        if (orb != null) {
            try { wm.removeView(orb) } catch (_: Exception) {}
            orb = null
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
