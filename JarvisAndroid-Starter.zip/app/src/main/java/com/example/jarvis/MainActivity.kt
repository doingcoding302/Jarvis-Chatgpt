package com.example.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingSpeech by mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent {
            JarvisScreen(
                onSpeak = { say(it) },
                onListen = { launchSpeechRecognition() },
                onEnableOverlay = { enableOverlay() },
                onToggleOverlay = { toggleOverlay() },
                initialPrompt = intent.getBooleanExtra("start_listening", false)
            )
        }
        requestNotificationPermission()
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            tts?.language = Locale.getDefault()
            tts?.setPitch(0.82f)
            if (pendingSpeech.isNotBlank()) say(pendingSpeech)
        }
    }

    private fun say(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
        else pendingSpeech = text
    }

    private fun launchSpeechRecognition() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to Jarvis")
        }
        try { speechLauncher.launch(intent) } catch (_: Exception) {
            say("Speech recognition is not available on this device.")
        }
    }

    private val speechLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) {
            val reply = AssistantRepository.reply(spoken)
            say(reply)
            setContent {
                JarvisScreen(
                    onSpeak = { say(it) }, onListen = { launchSpeechRecognition() },
                    onEnableOverlay = { enableOverlay() }, onToggleOverlay = { toggleOverlay() },
                    initialPrompt = false, initialUserText = spoken, initialReply = reply
                )
            }
        }
    }

    private fun enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                data = android.net.Uri.parse("package:$packageName")
            })
        } else toggleOverlay()
    }

    private fun toggleOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            enableOverlay()
            return
        }
        val i = Intent(this, OverlayService::class.java)
        startService(i)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            registerForActivityResult(ActivityResultContracts.RequestPermission()) {}.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun JarvisScreen(
    onSpeak: (String) -> Unit,
    onListen: () -> Unit,
    onEnableOverlay: () -> Unit,
    onToggleOverlay: () -> Unit,
    initialPrompt: Boolean,
    initialUserText: String = "",
    initialReply: String = ""
) {
    var assistantName by remember { mutableStateOf("Jarvis") }
    var userName by remember { mutableStateOf("Boss") }
    var businessMode by remember { mutableStateOf(false) }
    var dark by remember { mutableStateOf(true) }
    var query by remember { mutableStateOf(initialUserText) }
    var reply by remember { mutableStateOf(initialReply) }
    val bg = if (dark) Color(0xFF070A12) else Color(0xFFF2F6FF)
    val panel = if (dark) Color(0xFF111827) else Color.White
    val fg = if (dark) Color(0xFFF2F6FF) else Color(0xFF111827)
    val accent = Color(0xFF65E7FF)
    val pulse = rememberInfiniteTransition(label = "orb")
    val scale by pulse.animateFloat(0.96f, 1.05f, infiniteRepeatable(tween(1600), RepeatMode.Reverse), label = "scale")

    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(bg, if (dark) Color(0xFF111B35) else Color(0xFFE4ECFF)))) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("NEXUS / AI CORE", color = accent, style = MaterialTheme.typography.labelMedium)
                            Text(assistantName, color = fg, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                            Text(if (businessMode) "COMMERCIAL MODE" else "PERSONAL MODE", color = fg.copy(alpha = .65f))
                        }
                        IconButton(onClick = { dark = !dark }) {
                            Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode, contentDescription = "Toggle theme", tint = fg)
                        }
                    }
                }
                item {
                    Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                        Box(
                            Modifier.size((176 * scale).dp).clip(CircleShape)
                                .background(Brush.radialGradient(listOf(Color(0xFF65E7FF).copy(alpha=.42f), Color(0xFF4169E1).copy(alpha=.13f), Color.Transparent)))
                                .border(1.dp, accent.copy(alpha=.75f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(Modifier.size(112.dp).clip(CircleShape)
                                .background(Brush.linearGradient(listOf(Color(0xFF1B3154), Color(0xFF0A0E1B))))
                                .border(2.dp, accent.copy(alpha=.8f), CircleShape), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.GraphicEq, null, tint = accent, modifier = Modifier.size(52.dp))
                            }
                        }
                    }
                    Text("Systems online • Ready when you are", color = fg.copy(alpha=.7f), modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = onListen, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF176B87))) {
                            Icon(Icons.Default.Mic, null); Spacer(Modifier.width(6.dp)); Text("Talk to $assistantName")
                        }
                        OutlinedButton(onClick = onToggleOverlay, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.BubbleChart, null); Spacer(Modifier.width(5.dp)); Text("Floating orb")
                        }
                    }
                }
                item {
                    GlassPanel(panel, fg, "ASSISTANT RESPONSE") {
                        Text(if (reply.isBlank()) "At your service, $userName. Tap Talk to speak. This starter uses demo responses until an AI backend is connected." else reply, color = fg)
                        if (query.isNotBlank()) Text("You: $query", color = fg.copy(alpha=.65f), style = MaterialTheme.typography.bodySmall)
                    }
                }
                item {
                    GlassPanel(panel, fg, "PREFERENCES") {
                        OutlinedTextField(assistantName, { assistantName = it }, label = { Text("Assistant name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(userName, { userName = it }, label = { Text("What should it call you?") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Commercial / business mode", color = fg)
                            Switch(checked = businessMode, onCheckedChange = { businessMode = it })
                        }
                        Button(onClick = onEnableOverlay, modifier = Modifier.fillMaxWidth()) { Text("Enable screen overlay") }
                    }
                }
                item {
                    GlassPanel(panel, fg, "CAPABILITIES ROADMAP") {
                        Text("• Voice chat and multilingual speech\n• Floating orb overlay\n• Personal and business modes\n• YouTube analytics alerts (integration needed)\n• App launching and deeper actions (permissions needed)", color = fg)
                    }
                }
                item {
                    Text("Prototype v0.1 • More integrations can be added safely", color = fg.copy(alpha=.55f), style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun GlassPanel(panel: Color, fg: Color, title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
            .background(panel.copy(alpha=.88f))
            .border(1.dp, Color(0xFF65E7FF).copy(alpha=.22f), RoundedCornerShape(24.dp))
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(title, color = Color(0xFF65E7FF), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
        content()
    }
}

object AssistantRepository {
    fun reply(input: String): String {
        val q = input.lowercase(Locale.getDefault())
        return when {
            "hello" in q || "hi" in q || "hey" in q -> "Hello. I'm online and ready to help."
            "time" in q -> "I can add live time and calendar tools when the assistant backend is connected."
            "youtube" in q || "viral" in q -> "YouTube channel monitoring needs your authorized Google account and YouTube Data API integration."
            "open" in q -> "App launching can be added through Android intents for supported apps."
            else -> "I heard you say: $input. Connect a secure AI backend to enable intelligent answers and actions."
        }
    }
}
